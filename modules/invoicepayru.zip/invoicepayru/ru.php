<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{invoicepayru}prestashop>invoicepayru_556299f1e70e5e0957af6d602735ffc9'] = 'Счет на оплату (Россия)';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_6f31652c38bbd89f53a215d4a0cd135f'] = 'Отображает счет на оплату';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_50ed72def203c4475e9c47e6c0c150b1'] = 'Пожалуйста, добавьте префикс';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_ca3fb3af077e372d8592dc5a167c723c'] = 'Поставщик:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Пример:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_cce9f8d0ac972e10b45008966ea78a4a'] = 'Юр/адрес:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_2064d1cb8776231791425d5059b6a587'] = 'Факт/адрес:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_8083fc0ce44f512c9f5574e6d7526566'] = 'ИНН:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_e79181988782eac6acddc1fcebfb4b29'] = 'КПП:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_49ce1af063723c11531d888aac436a33'] = 'Р/С:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_98ea7ce1891cde885992cdb1f17d66ef'] = 'БИК:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_c96691412c608f8e4c5e666b7dbad646'] = 'К/С';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_b88834b7e550618a239da9713ca4014d'] = 'Адрес банка:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_211f9ac1dbcd06695f6ff6cd303455c6'] = 'Префикс:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_8e12e1a33edb03467ace29d30e210e83'] = 'Пример: PX-';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_7bfdac295dda79ea24ce4e0d1b2219a7'] = 'Показывать логотип:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_93cba07454f06a4a960172bbd6e2a435'] = 'Да';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_8b4efa7471088779f7342299f8b69182'] = 'Показывать логотип в инвойсе';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_ad0dabcec7cadab417b45db7259b475c'] = 'Считать НДС';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_917dd2486c5948c8652b230a6fe51e62'] = 'Считать НДС в модуле';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_a07704a03878a1b3bd28c86ab210f6fe'] = 'Добавить доставку:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_863daacb97b860d442e8d335290ce842'] = 'Добавить в счет стоимость доставки';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_3007fad3642926f9f3208cf889f96e12'] = 'Добавить текст:';
$_MODULE['<{invoicepayru}prestashop>invoicepayru_b17f3f4dcf653a5776792498a9b44d6a'] = 'Обновить настройки';
